function varargout = untitled(varargin)
% UNTITLED MATLAB code for untitled.fig
%      UNTITLED, by itself, creates a new UNTITLED or raises the existing
%      singleton*.
%
%      H = UNTITLED returns the handle to a new UNTITLED or the handle to
%      the existing singleton*.
%
%      UNTITLED('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in UNTITLED.M with the given input arguments.
%
%      UNTITLED('Property','Value',...) creates a new UNTITLED or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before untitled_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to untitled_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help untitled

% Last Modified by GUIDE v2.5 14-Jan-2020 16:00:12

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @untitled_OpeningFcn, ...
                   'gui_OutputFcn',  @untitled_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before untitled is made visible.
function untitled_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to untitled (see VARARGIN)

% Choose default command line output for untitled
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes untitled wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = untitled_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;



function frenquency_input_Callback(hObject, eventdata, handles)
% hObject    handle to frenquency_input (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of frenquency_input as text
%        str2double(get(hObject,'String')) returns contents of frenquency_input as a double


% --- Executes during object creation, after setting all properties.
function frenquency_input_CreateFcn(hObject, eventdata, handles)
% hObject    handle to frenquency_input (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function A_input_Callback(hObject, eventdata, handles)
% hObject    handle to A_input (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of A_input as text
%        str2double(get(hObject,'String')) returns contents of A_input as a double


% --- Executes during object creation, after setting all properties.
function A_input_CreateFcn(hObject, eventdata, handles)
% hObject    handle to A_input (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function phase_input_Callback(hObject, eventdata, handles)
% hObject    handle to phase_input (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of phase_input as text
%        str2double(get(hObject,'String')) returns contents of phase_input as a double


% --- Executes during object creation, after setting all properties.
function phase_input_CreateFcn(hObject, eventdata, handles)
% hObject    handle to phase_input (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function timelength_input_Callback(hObject, eventdata, handles)
% hObject    handle to timelength_input (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of timelength_input as text
%        str2double(get(hObject,'String')) returns contents of timelength_input as a double


% --- Executes during object creation, after setting all properties.
function timelength_input_CreateFcn(hObject, eventdata, handles)
% hObject    handle to timelength_input (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function fs_input_Callback(hObject, eventdata, handles)
% hObject    handle to fs_input (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of fs_input as text
%        str2double(get(hObject,'String')) returns contents of fs_input as a double


% --- Executes during object creation, after setting all properties.
function fs_input_CreateFcn(hObject, eventdata, handles)
% hObject    handle to fs_input (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit6_Callback(hObject, eventdata, handles)
% hObject    handle to edit6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit6 as text
%        str2double(get(hObject,'String')) returns contents of edit6 as a double


% --- Executes during object creation, after setting all properties.
function edit6_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
end


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
key = get(handles.popupmenu1,'value')
switch key
    case 2
        f = str2double(get(handles.frenquency_input,'string'));
        A = str2double(get(handles.A_input,'string'));
        T = str2double(get(handles.timelength_input,'string'));
        fs = str2double(get(handles.fs_input,'string'));
        fai = str2double(get(handles.phase_input,'string'));
        N = T * fs;
        n = 0:N-1;
        t = n/fs;
        y = A * sin(2*pi*f*t+fai);
        plot(handles.axes1,t,y); 
        xlabel(handles.axes1,'t/s');
        ylabel(handles.axes1,'y/V');
        handles.y = y;
        handles.t = t;
        guidata(hObject, handles);
        
       
    case 3
         f = str2double(get(handles.frenquencys_input,'string'));
         A = str2double(get(handles.A_input,'string'));
         a = str2double(get(handles.duty,'string'));
         T = str2double(get(handles.timelength_input,'string'));
         fs = str2double(get(handles.fs_input,'string'));
         N = T * fs;
         n = 0:N-1;
         t = n/fs;
         y = A * square(2*pi*f*t,a);
         plot(handles.axes1,t,y);
         xlabel(handles.axes1,'t/s');
         ylabel(handles.axes1,'y/V');
         handles.y = y;
         handles.t = t;
         guidata(hObject, handles);
         
    case 4
        f1 = str2double(get(handles.frenquency1_input,'string'));
        f2 = str2double(get(handles.frenquency2_input,'string'));
        A = str2double(get(handles.A_input,'string'));
        T = str2double(get(handles.timelength_input,'string'));
        fs = str2double(get(handles.fs_input,'string'));
        N = T * fs;
        n = 0:N-1;
        t = n/fs;
        y = A*sin(2*pi*f1*t) + A*sin(2*pi*f2*t);
        plot(handles.axes1,t,y);
        xlabel(handles.axes1,'t/s');
        ylabel(handles.axes1,'y/V');
        handles.y = y;
        handles.t = t;
        guidata(hObject, handles);
        
    case 5
        T = str2double(get(handles.timenoise,'string'));
        D = str2double(get(handles.variance_input,'string'));
        fs = str2double(get(handles.frenquencyn_input,'string'));
        N = T * fs;
        n = 0:N-1;
        t = n/fs;
        y = normrnd(0,D^(1/2),1,N);
        plot(handles.axes1,y);
        xlabel(handles.axes1,'t/s');
        ylabel(handles.axes1,'y/V');
        handles.y = y;
        handles.t = t;
        guidata(hObject, handles);
        
    case 6
        T = str2double(get(handles.timenoise,'string'));
        D = str2double(get(handles.variance_input,'string'));
        fs = str2double(get(handles.frenquencyn_input,'string'));
        N = T * fs;
        n = 0:N-1;
        t = n/fs;
        y1 = rand(1,N);
        y1 = y1 - mean(y1);
        d = sqrt(12*D);
        y = d*y1; 
        plot(handles.axes1,y);
        xlabel(handles.axes1,'t/s');
        ylabel(handles.axes1,'y/V');
        handles.y = y;
        handles.t = t;
        guidata(hObject, handles);
        
    case 7
        load('G:\SSVEP\SSVEP_1_1kHz.mat');
        ys2 = reshape(x(1,1:1024,1:50),1,[]);
        y = ys2;
        plot(handles.axes1,y);
        xlabel(handles.axes1,'t/s');
        ylabel(handles.axes1,'y/V');
        handles.y = y;
        guidata(hObject, handles);
        
    case 8
        load('G:\SSVEP\SSVEP_2_256Hz.mat');
        ys2 = reshape(x(1,1:1024,1:50),1,[]);
        y = ys2;
        plot(handles.axes1,y);
        xlabel(handles.axes1,'t/s');
        ylabel(handles.axes1,'y/V');
        handles.y = y;
        guidata(hObject, handles);
        
end


% --- Executes on selection change in popupmenu1.
function popupmenu1_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu1 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu1


% --- Executes during object creation, after setting all properties.
function popupmenu1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function duty_Callback(hObject, eventdata, handles)
% hObject    handle to duty (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of duty as text
%        str2double(get(hObject,'String')) returns contents of duty as a double


% --- Executes during object creation, after setting all properties.
function duty_CreateFcn(hObject, eventdata, handles)
% hObject    handle to duty (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function frenquencys_input_Callback(hObject, eventdata, handles)
% hObject    handle to frenquencys_input (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of frenquencys_input as text
%        str2double(get(hObject,'String')) returns contents of frenquencys_input as a double


% --- Executes during object creation, after setting all properties.
function frenquencys_input_CreateFcn(hObject, eventdata, handles)
% hObject    handle to frenquencys_input (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function frenquency1_input_Callback(hObject, eventdata, handles)
% hObject    handle to frenquency1_input (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of frenquency1_input as text
%        str2double(get(hObject,'String')) returns contents of frenquency1_input as a double


% --- Executes during object creation, after setting all properties.
function frenquency1_input_CreateFcn(hObject, eventdata, handles)
% hObject    handle to frenquency1_input (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function timenoise_Callback(hObject, eventdata, handles)
% hObject    handle to timenoise (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of timenoise as text
%        str2double(get(hObject,'String')) returns contents of timenoise as a double


% --- Executes during object creation, after setting all properties.
function timenoise_CreateFcn(hObject, eventdata, handles)
% hObject    handle to timenoise (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function frenquencyn_input_Callback(hObject, eventdata, handles)
% hObject    handle to frenquencyn_input (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of frenquencyn_input as text
%        str2double(get(hObject,'String')) returns contents of frenquencyn_input as a double


% --- Executes during object creation, after setting all properties.
function frenquencyn_input_CreateFcn(hObject, eventdata, handles)
% hObject    handle to frenquencyn_input (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function variance_input_Callback(hObject, eventdata, handles)
% hObject    handle to variance_input (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of variance_input as text
%        str2double(get(hObject,'String')) returns contents of variance_input as a double


% --- Executes during object creation, after setting all properties.
function variance_input_CreateFcn(hObject, eventdata, handles)
% hObject    handle to variance_input (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
key = get(handles.popupmenu1,'value')
switch key
    case 2
        fs = str2double(get(handles.fs_input,'string'));
        y = handles.y;
        nfft = 2048;
        Y=fft(y,nfft);
        f=fs*(0:nfft/2)/nfft;
        A=abs(Y(1:(nfft/2)+1));
        phi=angle(Y(1:(nfft/2)+1));
        plot(handles.axes2,f,A);
        xlabel(handles.axes2,'f/Hz');
        ylabel(handles.axes2,'H(\omega)');
        plot(handles.axes3,f,phi);
        xlabel(handles.axes3,'f/Hz');
        ylabel(handles.axes3,'\phi/rad');
       
    case 3
        y = handles.y;
        fs = str2double(get(handles.fs_input,'string'));
        nfft=2048;
        Y=fft(y,nfft);
        f=fs*(0:nfft/2)/nfft;
        A=abs(Y(1:(nfft/2)+1));
        phi=angle(Y(1:(nfft/2)+1));
        plot(handles.axes2,f,A);
        xlabel(handles.axes2,'f/Hz');
        ylabel(handles.axes2,'H(\omega)');
        plot(handles.axes3,f,phi);
        xlabel(handles.axes3,'f/Hz');
        ylabel(handles.axes3,'\phi/rad');
         
    case 4
        y = handles.y;
        fs = str2double(get(handles.fs_input,'string'));
        nfft=2048;
        Y=fft(y,nfft);
        f=fs*(0:nfft/2)/nfft;
        A=abs(Y(1:(nfft/2)+1));
        phi=angle(Y(1:(nfft/2)+1));
        plot(handles.axes2,f,A);
        xlabel(handles.axes2,'f/Hz');
        ylabel(handles.axes2,'H(\omega)');
        plot(handles.axes3,f,phi);
        xlabel(handles.axes3,'f/Hz');
        ylabel(handles.axes3,'\phi/rad');
        
    case 5
        y = handles.y;
        fs = str2double(get(handles.frenquencyn_input,'string'));
        nfft=2048;
        Y=fft(y,nfft);
        f=fs*(0:nfft/2)/nfft;
        A=abs(Y(1:(nfft/2)+1));
        phi=angle(Y(1:(nfft/2)+1));
        plot(handles.axes2,f,A);
        xlabel(handles.axes2,'f/Hz');
        ylabel(handles.axes2,'H(\omega)');
        plot(handles.axes3,f,phi);
        xlabel(handles.axes3,'f/Hz');
        ylabel(handles.axes3,'\phi/rad');
        
    case 6
        y = handles.y;
        fs = str2double(get(handles.frenquencyn_input,'string'));
        nfft=2048;
        Y=fft(y,nfft);
        f=fs*(0:nfft/2)/nfft;
        A=abs(Y(1:(nfft/2)+1));
        phi=angle(Y(1:(nfft/2)+1));
        plot(handles.axes2,f,A);
        xlabel(handles.axes2,'f/Hz');
        ylabel(handles.axes2,'H(\omega)');
        plot(handles.axes3,f,phi);
        xlabel(handles.axes3,'f/Hz');
        ylabel(handles.axes3,'\phi/rad');
        
    case 7
        load('G:\SSVEP\SSVEP_1_1kHz.mat');
        M = mean(x(:,:,1:50),3);
        y = squeeze(x(2,:,1:50));
        y1 = zeros(6000,50);
        for i = 1 : 1000
            for j = 1 : 6000
                for k = 1 : 50
                    y1(j,k) = y(j,k) + y1(j,k);
                end
            end
        end
        fs = 1000;
        nfft=2048;
        Y=fft(y1,nfft);
        f=fs*(0:nfft/2)/nfft;
        A=abs(Y(1:(nfft/2)+1));
        phi=angle(Y(1:(nfft/2)+1));  
        plot(handles.axes2,f,A);
        xlim(handles.axes2,[0 80]);
        xlabel(handles.axes2,'f/Hz');
        ylabel(handles.axes2,'H(\omega)');
        plot(handles.axes3,f,phi);
        xlabel(handles.axes3,'f/Hz');
        ylabel(handles.axes3,'\phi/rad');
        
    case 8
       load('G:\SSVEP\SSVEP_2_256Hz.mat');
        M = mean(x(:,:,1:50),3);
        y = squeeze(x(2,:,1:50));
        y1 = zeros(1088,50);
        for i = 1 : 1000
            for j = 1 : 1088
                for k = 1 : 50
                    y1(j,k) = y(j,k) + y1(j,k);
                end
            end
        end
        fs = 1000;
        nfft=2048;
        Y=fft(y1,nfft);
        f=fs*(0:nfft/2)/nfft;
        A=abs(Y(1:(nfft/2)+1));
        phi=angle(Y(1:(nfft/2)+1));  
        plot(handles.axes2,f,A);
        xlim(handles.axes2,[0 100]);
        xlabel(handles.axes2,'f/Hz');
        ylabel(handles.axes2,'H(\omega)');
        plot(handles.axes3,f,phi);
        xlabel(handles.axes3,'f/Hz');
        ylabel(handles.axes3,'\phi/rad');
end


% --- Executes on button press in pushbutton3.
function pushbutton3_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
key = get(handles.popupmenu1,'value');
switch key
    case 2
        fs = str2double(get(handles.fs_input,'string'));
        y = handles.y;
        nfft = 2^15;
        Ry = xcorr(y);
        Y=fft(Ry,nfft);
        f=fs*(0:nfft/2)/nfft;
        A=10*log10(abs(Y(1:(nfft/2)+1)));
        plot(handles.axes4,f,A);
        xlabel(handles.axes4,'f/Hz');
        ylabel(handles.axes4,'P(\omega)/dB');
        
    case 3
         y = handles.y;
         fs = str2double(get(handles.fs_input,'string'));
         nfft = 2^15;
         Ry = xcorr(y);
         Y=fft(Ry,nfft);
         f=fs*(0:nfft/2)/nfft;
         A=10*log10(abs(Y(1:(nfft/2)+1)));
         plot(handles.axes4,f,A);
         xlabel(handles.axes4,'f/Hz');
         ylabel(handles.axes4,'P(\omega)/dB');
         
    case 4
        y = handles.y;
        fs = str2double(get(handles.fs_input,'string'));
        nfft = 2^15;
        Ry = xcorr(y);
        Y=fft(Ry,nfft);
        f=fs*(0:nfft/2)/nfft;
        A=10*log10(abs(Y(1:(nfft/2)+1)));
        plot(handles.axes4,f,A);
        xlabel(handles.axes4,'f/Hz');
        ylabel(handles.axes4,'P(\omega)/dB');
        
    case 5
        y = handles.y;
        fs = str2double(get(handles.frenquencyn_input,'string'));
        nfft=2^15;
        Ry = xcorr(y);
        Y=fft(Ry,nfft);
        f=fs*(0:nfft/2)/nfft;
        A=10*log10(abs(Y(1:(nfft/2)+1))); 
        plot(handles.axes4,f,A);
        xlabel(handles.axes4,'f/Hz');
        ylabel(handles.axes4,'P(\omega)/dB');
        
    case 6
        y = handles.y;
        fs = str2double(get(handles.frenquencyn_input,'string'));
        nfft=2^15;
        Ry = xcorr(y);
        Y=fft(Ry,nfft);
        f=fs*(0:nfft/2)/nfft;
        A=10*log10(abs(Y(1:(nfft/2)+1))); 
        plot(handles.axes4,f,A);
        xlabel(handles.axes4,'f/Hz');
        ylabel(handles.axes4,'P(\omega)/dB');
        
     case 7
        load('G:\SSVEP\SSVEP_1_1kHz.mat');
        M = mean(x(:,:,1:50),3);
        y = squeeze(x(2,:,1:50));
        y1 = zeros(6000,50);
        for i = 1 : 50
            for j = 1 : 6000
                for k = 1 : 50
                    y1(j,k) = y(j,k) + y1(j,k);
                end
            end
        end
        fs = 1000;
        nfft=2^15;
        Ry = xcorr(y1);
        Y=fft(Ry,nfft);
        f=fs*(0:nfft/2)/nfft;
        A=10*log10(abs(Y(1:(nfft/2)+1))); 
        plot(handles.axes4,f,A);
        xlabel(handles.axes4,'f/Hz');
        ylabel(handles.axes4,'P(\omega)/dB'); 
     case 8
        load('G:\SSVEP\SSVEP_2_256Hz.mat');
        M = mean(x(:,:,1:50),3);
        y = squeeze(x(2,:,1:50));
        y1 = zeros(1088,50);
        for i = 1 : 50
            for j = 1 : 1088
                for k = 1 : 50
                    y1(j,k) = y(j,k) + y1(j,k);
                end
            end
        end
        fs = 1000;
        nfft=2^15;
        Ry = xcorr(y1);
        Y=fft(Ry,nfft);
        f=fs*(0:nfft/2)/nfft;
        A=10*log10(abs(Y(1:(nfft/2)+1))); 
        plot(handles.axes4,f,A);
        xlabel(handles.axes4,'f/Hz');
        ylabel(handles.axes4,'P(\omega)/dB'); 
end  


% --- Executes on selection change in popupmenu3.
function popupmenu3_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu3 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu3


% --- Executes during object creation, after setting all properties.
function popupmenu3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function passband_input_Callback(hObject, eventdata, handles)
% hObject    handle to passband_input (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of passband_input as text
%        str2double(get(hObject,'String')) returns contents of passband_input as a double


% --- Executes during object creation, after setting all properties.
function passband_input_CreateFcn(hObject, eventdata, handles)
% hObject    handle to passband_input (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function in_band_input_Callback(hObject, eventdata, handles)
% hObject    handle to in_band_input (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of in_band_input as text
%        str2double(get(hObject,'String')) returns contents of in_band_input as a double


% --- Executes during object creation, after setting all properties.
function in_band_input_CreateFcn(hObject, eventdata, handles)
% hObject    handle to in_band_input (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function stopband_input_Callback(hObject, eventdata, handles)
% hObject    handle to stopband_input (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of stopband_input as text
%        str2double(get(hObject,'String')) returns contents of stopband_input as a double


% --- Executes during object creation, after setting all properties.
function stopband_input_CreateFcn(hObject, eventdata, handles)
% hObject    handle to stopband_input (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function out_of_band_input_Callback(hObject, eventdata, handles)
% hObject    handle to out_of_band_input (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of out_of_band_input as text
%        str2double(get(hObject,'String')) returns contents of out_of_band_input as a double


% --- Executes during object creation, after setting all properties.
function out_of_band_input_CreateFcn(hObject, eventdata, handles)
% hObject    handle to out_of_band_input (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton4.
function pushbutton4_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
key2 = get(handles.popupmenu3,'value')
switch key2
    case 2      %IIR��ͨ
        F1 = str2double(get(handles.passband_input,'string'));
        F2 = str2double(get(handles.stopband_input,'string'));
        fs = str2double(get(handles.fs_input,'string'));
        rp = str2double(get(handles.in_band_input,'string'));
        rs = str2double(get(handles.out_of_band_input,'string'));
        wp = F1*2/fs;
        ws = F2*2/fs;
        [N,Wn] = buttord(wp,ws,rp,rs);
        [bz,az] = butter(N,Wn);
        [h,w] = freqz(bz,az,256,fs);
        h1 = 20*log10(abs(h));
        plot(handles.axes5,w,h1);
        ylim(handles.axes5,[-100 0]);
        xlabel(handles.axes5,'f/Hz');
        ylabel(handles.axes5,'H(\omega)');
        phi = angle(h);
        plot(handles.axes6,w,phi);
        xlabel(handles.axes6,'f/Hz');
        ylabel(handles.axes6,'\phi/rad');
        handles.bz = bz;
        handles.az = az;
        guidata(hObject, handles);
        
    case 3              %FIR��ͨ
        F1 = str2double(get(handles.passband_input,'string'));
        F2 = str2double(get(handles.stopband_input,'string'));
        fs = str2double(get(handles.fs_input,'string'));
        rp = str2double(get(handles.in_band_input,'string'));
        rs = str2double(get(handles.out_of_band_input,'string'));
        WP = F1*2*pi;
        WS = F2*2*pi;
        [N,Wn] = cheb2ord(WP,WS,rp,rs,'s');
        [Z,P,K] = cheb2ap(N,rs);
        [A,B,C,D] = zp2ss(Z,P,K);
        [AA,BB,CC,DD] = lp2hp(A,B,C,D,Wn);
        [a,b,c,d] = bilinear(AA,BB,CC,DD,fs);
        [P,Q] = ss2tf(a,b,c,d);
        [H,W] = freqz(P,Q);
        H1 = abs(H);
        plot(handles.axes5,W*fs/(2*pi),H1);
        xlabel(handles.axes5,'f/Hz');
        ylabel(handles.axes5,'H(\omega)');
        PHI = angle(H);
        plot(handles.axes6,W*fs/(2*pi),PHI);
        xlabel(handles.axes6,'f/Hz');
        ylabel(handles.axes6,'\phi/rad');
        handles.P = P;
        handles.Q = Q;
        guidata(hObject, handles);
        
end

% --- Executes on button press in pushbutton5.
function pushbutton5_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
key2 = get(handles.popupmenu3,'value')
switch key2
    case 2
        y = handles.y;
        t = handles.t;
        fs = str2double(get(handles.fs_input,'string'));
        bz = handles.bz;
        az = handles.az;
        y1 = filter(bz,az,y);
        plot(handles.axes7,t,y1);
        xlabel(handles.axes7,'t/s');
        ylabel(handles.axes7,'y');
        nfft = 2^15;
        Y=fft(y1,nfft);
        f=fs*(0:nfft/2)/nfft;
        A=abs(Y(1:(nfft/2)+1));
        phi=angle(Y(1:(nfft/2)+1));
        plot(handles.axes8,f,A);
        xlabel(handles.axes8,'f/Hz');
        ylabel(handles.axes8,'H(\omega)');
        plot(handles.axes9,f,phi);
        xlabel(handles.axes9,'f/Hz');
        ylabel(handles.axes9,'\phi/rad');
        
    case 3 
        y = handles.y;
        t = handles.t;
        fs = str2double(get(handles.fs_input,'string'));
        P = handles.P;
        Q = handles.Q;
        y1 = filter(P,Q,y);
        plot(handles.axes7,t,y1);
        xlabel(handles.axes7,'t/s');
        ylabel(handles.axes7,'y');
        nfft = 2^15;
        Y=fft(y1,nfft);
        f=fs*(0:nfft/2)/nfft;
        A=abs(Y(1:(nfft/2)+1));
        phi=angle(Y(1:(nfft/2)+1));
        plot(handles.axes8,f,A);
        xlabel(handles.axes8,'f/Hz');
        ylabel(handles.axes8,'H(\omega)');
        plot(handles.axes9,f,phi);
        xlabel(handles.axes9,'f/Hz');
        ylabel(handles.axes9,'\phi/rad');
        
end    
